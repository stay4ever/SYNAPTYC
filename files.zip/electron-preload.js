/**
 * Preload Script — Secure IPC Bridge
 * Exposes only whitelisted APIs to the renderer via contextBridge.
 * Never expose ipcRenderer directly.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Platform info
  getPlatform:    ()  => ipcRenderer.invoke('get-platform'),
  getAppVersion:  ()  => ipcRenderer.invoke('get-app-version'),

  // Security actions
  saveKeyFingerprint: (fp) => ipcRenderer.invoke('save-key-fingerprint', fp),

  // Listen for main-process events
  onNewSession:       (cb) => ipcRenderer.on('new-session',         () => cb()),
  onShowKeys:         (cb) => ipcRenderer.on('show-keys',           () => cb()),
  onRotateKeys:       (cb) => ipcRenderer.on('rotate-keys',         () => cb()),
  onClearMessages:    (cb) => ipcRenderer.on('clear-messages',      () => cb()),
  onExportFingerprint:(cb) => ipcRenderer.on('export-fingerprint',  () => cb()),

  // Cleanup listeners
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel),
});
