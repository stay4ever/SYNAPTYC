/**
 * SecureChat — Electron Main Process
 * Supports: Windows 10/11, macOS 12+
 */

const { app, BrowserWindow, Menu, Tray, nativeImage, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const isDev = process.env.NODE_ENV === 'development';

let mainWindow;
let tray;

// ── Security: disable Node in renderer ────────────────────────────────────
app.commandLine.appendSwitch('disable-features', 'OutOfBlinkCors');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    minWidth: 800,
    minHeight: 560,
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    backgroundColor: '#0a0b0f',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      nodeIntegration: false,          // Never enable — security risk
      contextIsolation: true,          // Enforces process separation
      sandbox: true,                   // Additional sandboxing
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: true,
    },
    show: false,                       // Show only when ready
  });

  // Load the React app (built) or dev server
  if (isDev) {
    mainWindow.loadURL('http://localhost:3000');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, 'build', 'index.html'));
  }

  mainWindow.once('ready-to-show', () => mainWindow.show());

  mainWindow.on('close', (e) => {
    if (process.platform === 'darwin') {
      e.preventDefault();
      mainWindow.hide(); // macOS: hide to dock instead of quit
    }
  });
}

// ── System Tray ────────────────────────────────────────────────────────────
function createTray() {
  const icon = nativeImage.createFromPath(path.join(__dirname, 'assets', 'tray-icon.png'));
  tray = new Tray(icon.resize({ width: 16, height: 16 }));

  const menu = Menu.buildFromTemplate([
    { label: 'Open SecureChat',   click: () => mainWindow.show() },
    { type: 'separator' },
    { label: 'Quit',              click: () => { app.isQuitting = true; app.quit(); } },
  ]);

  tray.setToolTip('SecureChat — Encrypted Messaging');
  tray.setContextMenu(menu);
  tray.on('click', () => mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show());
}

// ── App Menu (macOS) ───────────────────────────────────────────────────────
function setAppMenu() {
  const template = [
    ...(process.platform === 'darwin' ? [{
      label: app.name,
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        { role: 'hide' }, { role: 'hideOthers' },
        { type: 'separator' },
        { role: 'quit' },
      ],
    }] : []),
    {
      label: 'File',
      submenu: [
        { label: 'New Secure Session', accelerator: 'CmdOrCtrl+N', click: () => mainWindow.webContents.send('new-session') },
        { type: 'separator' },
        process.platform === 'darwin' ? { role: 'close' } : { role: 'quit' },
      ],
    },
    { role: 'editMenu' },
    { role: 'viewMenu' },
    {
      label: 'Security',
      submenu: [
        { label: 'View Encryption Keys', accelerator: 'CmdOrCtrl+K', click: () => mainWindow.webContents.send('show-keys') },
        { label: 'Rotate Session Keys',  click: () => mainWindow.webContents.send('rotate-keys') },
        { label: 'Export Key Fingerprint', click: () => mainWindow.webContents.send('export-fingerprint') },
        { type: 'separator' },
        { label: 'Clear All Messages',   click: () => {
          dialog.showMessageBox(mainWindow, {
            type: 'warning', buttons: ['Clear', 'Cancel'], defaultId: 1,
            message: 'Clear all messages?', detail: 'This cannot be undone.',
          }).then(({ response }) => { if (response === 0) mainWindow.webContents.send('clear-messages'); });
        }},
      ],
    },
    { role: 'windowMenu' },
    {
      label: 'Help',
      submenu: [
        { label: 'Documentation', click: () => shell.openExternal('https://ai-evolution.com.au/securechat/docs') },
        { label: 'About Encryption', click: () => shell.openExternal('https://ai-evolution.com.au/securechat/security') },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ── IPC Handlers ───────────────────────────────────────────────────────────
ipcMain.handle('get-platform', () => process.platform);
ipcMain.handle('get-app-version', () => app.getVersion());

ipcMain.handle('save-key-fingerprint', async (_, fingerprint) => {
  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    title: 'Export Key Fingerprint',
    defaultPath: `securechat-fingerprint-${Date.now()}.txt`,
    filters: [{ name: 'Text', extensions: ['txt'] }],
  });
  if (filePath) {
    require('fs').writeFileSync(filePath, `SecureChat Key Fingerprint\n\n${fingerprint}\n\nGenerated: ${new Date().toISOString()}`);
    return true;
  }
  return false;
});

// ── Lifecycle ──────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  createWindow();
  createTray();
  setAppMenu();

  app.on('activate', () => {           // macOS dock click
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else mainWindow.show();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => { app.isQuitting = true; });

// ── Security: block new window navigation ─────────────────────────────────
app.on('web-contents-created', (_, contents) => {
  contents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://') && !url.startsWith('http://localhost')) {
      e.preventDefault();
      shell.openExternal(url);
    }
  });
  contents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
});
